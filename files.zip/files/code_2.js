console.log("This is code file 2");
console.log("Printing variable 1");
console.log(test_var)
