console.log("This is code file 1");
console.log("Declaring variable 1");
var test_var = "This variable was defined in code file 1";
